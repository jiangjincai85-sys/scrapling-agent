#!/usr/bin/env python3
"""
Scrapling 自动爬虫引擎 v1.0
自动判断页面类型 → 选择合适 Fetcher → 提取数据 → 输出结构化结果

用法:
  python3 scraple.py --url "https://example.com"
  python3 scraple.py --url "https://example.com" --selector ".item" --fields "title:h2::text,price:.price::text"
  python3 scraple.py --url "https://example.com" --dynamic
  python3 scraple.py --url "https://example.com" --stealth
  python3 scraple.py --url "https://example.com/page/{}" --start 1 --end 5
  python3 scraple.py --url "https://example.com" --monitor --interval 3600
"""
import argparse
import json
import sys
import time
import hashlib
from urllib.parse import urlparse

def try_import():
    """尝试导入 scrapling，失败时给出安装提示"""
    try:
        from scrapling import Fetcher, StealthyFetcher, DynamicFetcher
        return Fetcher, StealthyFetcher, DynamicFetcher
    except ImportError:
        print("❌ 未安装 scrapling，请先安装：")
        print("   pip3 install 'scrapling[all]'")
        sys.exit(1)


def auto_detect_selectors(page):
    """
    自动检测页面的数据结构。
    尝试从常见语义标签/class 中提取数据。
    """
    result = {
        "title": None,
        "items": [],
        "type": "unknown",
        "fields_detected": []
    }

    # 1. 提取标题
    for sel in ["h1::text", "title::text", "h2::text"]:
        try:
            t = page.css(sel).get()
            if t:
                result["title"] = t.strip()[:100]
                break
        except:
            pass

    # 2. 检测页面类型
    # 检测是否有表格
    try:
        tables = page.css("table")
        if tables:
            result["type"] = "table"
            result["table_count"] = len(tables)
    except:
        pass

    # 检测是否有列表（ul/ol）
    try:
        lists = page.css("ul, ol")
        if lists:
            result["type"] = "list" if result["type"] == "unknown" else result["type"]
            result["list_count"] = len(lists)
    except:
        pass

    # 检测是否有重复的块级结构（卡片/条目）
    for sel in ["article", ".item", ".post", ".card", ".entry", ".product", ".quote", "li", "tr", "[class*=item]", "[class*=post]", "[class*=card]"]:
        try:
            items = page.css(sel)
            if len(items) >= 3:  # 有 3 个以上重复结构
                result["type"] = "cards"
                result["items"] = items
                result["item_count"] = len(items)
                result["item_selector"] = sel

                # 尝试自动检测字段（多个选择器，挑第一个命中的）
                first = items[0]
                detected = []
                field_candidates = [
                    ("标题", [".text::text", "h2::text", "h3::text", ".title::text", ".name::text"]),
                    ("链接", ["a::attr(href)"]),
                    ("描述", ["p::text", ".desc::text", ".description::text"]),
                    ("价格", [".price::text", ".cost::text"]),
                    ("作者", [".author::text"]),
                    ("时间", [".date::text", ".time::text", ".meta::text"]),
                ]
                for fname, sels in field_candidates:
                    for sel in sels:
                        try:
                            val = first.css(sel).get()
                            if val and val.strip():
                                detected.append(fname)
                                break
                        except:
                            continue
                result["fields_detected"] = detected
                break
        except:
            continue

    return result


def extract_by_fields(page, selector, fields_str):
    """
    按选择器和字段提取数据
    fields_str 格式: "title:h2::text,price:.price::text"
    注意：选择器内不支持逗号，每个字段用一个选择器
    """
    fields = {}
    if fields_str:
        for part in fields_str.split(","):
            if ":" not in part:
                continue
            colon_idx = part.index(":")
            name = part[:colon_idx].strip()
            sel = part[colon_idx+1:].strip()
            fields[name] = sel

    if selector:
        rows = page.css(selector)
    else:
        rows = [page]

    results = []
    for row in rows:
        item = {}
        for name, sel in fields.items():
            try:
                # 支持 ::text, ::attr(href), ::html
                if "::text" in sel or "::attr" in sel or "::html" in sel:
                    vals = row.css(sel).getall()
                else:
                    vals = row.css(sel + "::text").getall()
                val = " | ".join(v.strip() for v in vals if v and v.strip())
                item[name] = val
            except:
                item[name] = ""
        results.append(item)

    return results, fields


def main():
    Fetcher, StealthyFetcher, DynamicFetcher = try_import()

    parser = argparse.ArgumentParser(description="Scrapling 自动爬虫引擎")
    parser.add_argument("--url", required=False, help="要爬取的 URL")
    parser.add_argument("--selector", help="列表选择器（如 .item, article, tr）")
    parser.add_argument("--fields", help="字段映射（如 'title:h2::text,price:.price::text'）")
    parser.add_argument("--stealth", action="store_true", help="使用隐身模式绕过 Cloudflare")
    parser.add_argument("--dynamic", action="store_true", help="使用浏览器模式渲染 JS")
    parser.add_argument("--cookie", help="设置 Cookie（如 'key=value; key2=value2'）")
    parser.add_argument("--start", type=int, default=1, help="翻页起始页")
    parser.add_argument("--end", type=int, default=1, help="翻页结束页")
    parser.add_argument("--monitor", action="store_true", help="监控模式")
    parser.add_argument("--interval", type=int, default=3600, help="监控间隔秒数")
    parser.add_argument("--output", help="输出文件路径（默认自动生成）")
    parser.add_argument("--auto", action="store_true", help="自动模式：自动检测页面结构并提取")

    args = parser.parse_args()

    if not args.url:
        # 交互模式
        print("🕷️ Scrapling 爬虫助手")
        print("=" * 50)
        args.url = input("请输入要爬取的 URL: ").strip()
        if not args.url:
            print("❌ 需要提供 URL")
            sys.exit(1)

        mode = input("是否自动检测页面结构? (Y/n): ").strip().lower()
        args.auto = mode != "n"

        if not args.auto:
            sel = input("列表选择器 (如 .item, 留空则提取整页): ").strip()
            args.selector = sel if sel else None
            fields_input = input("字段映射 (如 '标题:h2,价格:.price', 留空自动检测): ").strip()
            args.fields = fields_input if fields_input else None

    all_data = []
    fetcher_type = "stealth" if args.stealth else ("dynamic" if args.dynamic else "auto")

    for page_num in range(args.start, args.end + 1):
        url = args.url.format(page_num) if "{}" in args.url else args.url
        print(f"🌐 正在访问: {url}")

        try:
            # === 选择 Fetcher ===
            if fetcher_type == "stealth":
                print("  使用 StealthyFetcher (隐身模式)...")
                f = StealthyFetcher()
                resp = f.get(url)
            elif fetcher_type == "dynamic":
                print("  使用 DynamicFetcher (浏览器模式)...")
                f = DynamicFetcher()
                resp = f.get(url)
            else:
                print("  使用 Fetcher (快速模式)...")
                f = Fetcher()
                resp = f.get(url)
                # 如果返回非 200，自动降级
                if resp.status >= 400:
                    print(f"  ⚠️ 返回 {resp.status}，降级为 StealthyFetcher...")
                    sf = StealthyFetcher()
                    resp = sf.get(url)

            # === 提取数据 ===
            page = resp
            print(f"  ✅ 状态: {resp.status} | DOM 元素: ~{len(page.css('*'))} 个")

            if args.auto:
                # 自动检测模式
                info = auto_detect_selectors(page)
                print(f"  页面类型: {info['type']}")

                if info.get("title"):
                    print(f"  页面标题: {info['title']}")

                if info.get("fields_detected"):
                    print(f"  检测到字段: {', '.join(info['fields_detected'])}")

                # 如果在表格里或者找到了重复结构
                if info["type"] == "table":
                    rows, fields = extract_by_fields(page, "tr", None)
                    if rows:
                        # 自动从表头获取字段名
                        headers = page.css("th::text").getall()
                        if not headers:
                            headers = page.css("thead td::text").getall()
                        if headers:
                            header_fields = {h: f"td:nth-child({i+1})::text" for i, h in enumerate(headers)}
                            rows, _ = extract_by_fields(page, "tr", ",".join(f"{k}:{v}" for k,v in header_fields.items()))
                        all_data.extend(rows)
                        print(f"  📊 表格: {len(rows)} 行 x {len(headers or fields)} 列")

                elif info.get("item_selector"):
                    # 卡片列表模式
                    sel = info["item_selector"]
                    auto_fields = {"内容": "::text"}

                    rows, fields = extract_by_fields(page, sel, None)
                    # 自动生成通用字段
                    if info.get("fields_detected"):
                        # 用检测到的字段（每个字段只用一个选择器）
                        generic_fields = {}
                        for fd in info["fields_detected"]:
                            sel_map = {
                                "标题": ".text::text",
                                "链接": "a::attr(href)",
                                "描述": "p::text",
                                "价格": ".price::text",
                                "作者": ".author::text",
                                "时间": ".date::text",
                            }
                            generic_fields[fd] = sel_map.get(fd, "::text")
                        rows, fields = extract_by_fields(page, sel, ",".join(f"{k}:{v}" for k,v in generic_fields.items()))
                    else:
                        # 纯文本提取
                        for i, row in enumerate(page.css(sel)):
                            item = {"序号": str(i + 1), "内容": row.css("::text").get() or ""}
                            all_data.append(item)
                        print(f"  📋 列表: {len(page.css(sel))} 条")

                    if rows:
                        all_data.extend(rows)
                        print(f"  📋 列表: {len(rows)} 条")

                else:
                    # 纯文本提取 - 取所有可见文本
                    all_text = page.css("::text").getall()
                    text = " ".join(t.strip() for t in all_text if t.strip())[:500]
                    if text:
                        print(f"  📄 正文预览: {text[:200]}...")
                    all_data.append({"url": url, "content": all_text})

            elif args.selector or args.fields:
                # 指定选择器模式
                rows, fields = extract_by_fields(page, args.selector, args.fields)
                all_data.extend(rows)
                print(f"  📊 提取: {len(rows)} 条")

            else:
                # 默认：输出页面基本信息
                info = auto_detect_selectors(page)
                print(f"\n📊 页面分析结果:")
                print(f"  标题: {info.get('title', '未检测到')}")
                print(f"  类型: {info['type']}")
                if info.get("item_count"):
                    print(f"  条目数: {info['item_count']} (选择器: {info['item_selector']})")
                if info.get("fields_detected"):
                    print(f"  可用字段: {', '.join(info['fields_detected'])}")
                print(f"  文本长度: {len(page.css('body::text').get() or '')} 字符")

        except Exception as e:
            print(f"  ❌ 失败: {e}")
            continue

        if args.start != args.end:
            time.sleep(1)  # 翻页礼貌停顿

    # === 输出结果 ===
    if all_data:
        print(f"\n{'='*50}")
        print(f"✅ 共提取 {len(all_data)} 条数据")

        # 展示前 3 条预览
        print(f"\n📋 预览 (前 {min(3, len(all_data))} 条):")
        for i, item in enumerate(all_data[:3]):
            print(f"  [{i+1}] {json.dumps(item, ensure_ascii=False)}")

        # 保存文件
        if args.output:
            output_path = args.output
        else:
            domain = urlparse(args.url).netloc.replace(".", "_")
            ts = time.strftime("%Y%m%d_%H%M%S")
            output_path = f"scrapling_output_{domain}_{ts}.json"

        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(all_data, f, ensure_ascii=False, indent=2)
        print(f"\n💾 已保存: {output_path}")

        # 监控模式
        if args.monitor or args.monitor:
            print(f"\n👀 监控模式已启动 (每 {args.interval} 秒检查一次)")
            page_hash = hashlib.md5(json.dumps(all_data, ensure_ascii=False).encode()).hexdigest()
            while True:
                time.sleep(args.interval)
                try:
                    f = StealthyFetcher() if args.stealth else Fetcher()
                    new_resp = f.get(args.url)
                    new_text = new_resp.text or ""
                    new_hash = hashlib.md5(new_text.encode()).hexdigest()
                    if new_hash != page_hash:
                        print(f"  ⚠️ 页面内容已变化!")
                        page_hash = new_hash
                    else:
                        print(f"  ✅ {time.strftime('%H:%M:%S')} 无变化")
                except Exception as e:
                    print(f"  ❌ 监控检查失败: {e}")
    else:
        print("\n❌ 未提取到任何数据")


if __name__ == "__main__":
    main()