# Scrapling v0.4.8 实际 API 速查

> ⚠️ 这是基于实际安装的 v0.4.8 版本验证过的 API，与官方 README 可能有差异

## 快速安装

```bash
pip3 install "scrapling[all]"
```

## Fetcher 三种选择

| Fetcher | 适用场景 | 依赖 |
|---------|---------|------|
| `Fetcher()` | 普通页面（无反爬） | 无额外依赖 |
| `StealthyFetcher()` | Cloudflare/Turnstile 反爬 | Playwright+Patchright |
| `DynamicFetcher()` | JS 动态渲染页面 | Playwright |

```python
from scrapling import Fetcher, StealthyFetcher, DynamicFetcher

f = Fetcher()
resp = f.get("https://example.com")
# Response 对象本身就是选择器
```

## Response 对象的实际方法（v0.4.8）

**Response 对象 = 选择器**，不需要 `.html` 属性。

### 选择元素

| 方法 | 用法 | 说明 |
|------|------|------|
| `css(sel)` | `page.css(".title")` | 返回 Selectors 列表 |
| `xpath(sel)` | `page.xpath("//h1")` | XPath 选择 |
| `find(sel)` | `page.find("div.title")` | 语法糖，类似 css |
| `find_all(filter)` | `page.find_all(tag="a")` | 按标签/属性筛选 |
| `find_by_text(text)` | `page.find_by_text("关键词")` | 按文本搜索元素 |

### 提取值

| 方法 | 用法 | 说明 |
|------|------|------|
| `.get()` | `page.css("h1").get()` | 返回第一个匹配的文本 |
| `.getall()` | `page.css("h2::text").getall()` | 返回所有匹配 |
| `.text` | `el.text` | 属性方式获取文本 |
| `.attrib` | `el.attrib` | 元素全部属性（字典） |
| `.tag` | `el.tag` | 元素标签名 |

### 选择器语法

| 语法 | 说明 | 示例 |
|------|------|------|
| `::text` | 只取文本 | `h2::text` |
| `::attr(href)` | 取属性值 | `a::attr(href)` |
| `.class` | CSS class | `.price` |
| `#id` | CSS ID | `#main` |
| `tag` | 标签名 | `article` |
| `parent > child` | 直接子元素 | `.item > h2` |
| `sel1, sel2` | 多项任选 | `h1::text, h2::text` |

### DOM 导航

| 方法 | 说明 |
|------|------|
| `el.parent` | 父元素 |
| `el.children` | 子元素列表 |
| `el.siblings` | 兄弟元素列表 |
| `el.next` | 下一个兄弟（注意：不是 next_sibling） |
| `el.previous` | 上一个兄弟 |
| `el.find_ancestor(filter)` | 向上找祖先 |

### ⚠️ 已知 API 差异（vs 官方文档）

| 文档说 | 实际 v0.4.8 | 影响 |
|--------|------------|------|
| `css_first(sel)` | ❌ 不存在，用 `css(sel)[0]` 或 `css(sel).get()` | 需要改 |
| `find_by_text(tag=...)` | ❌ 不支持 `tag` 参数 | 只传 text |
| `next_sibling` | ❌ 不存在，用 `next` | 属性不一样 |
| `previous_sibling` | ❌ 不存在，用 `previous` | 属性不一样 |
| `Response.html` | ❌ 不存在，Response 本身就是选择器 | 不用 .html |

## 完整示例

```python
from scrapling import Fetcher
import json

f = Fetcher()
page = f.get("https://quotes.toscrape.com/")

# 提取列表
items = page.css(".quote")
results = []
for item in items:
    results.append({
        "text": item.css(".text::text").get(),
        "author": item.css(".author::text").get(),
    })

print(json.dumps(results, ensure_ascii=False, indent=2))
```

## 自适应追踪

```python
# 首次：保存指纹
page.css(".price", auto_save=True)

# 网站改版后：自动恢复
page.css(".price", adaptive=True)
```

## 翻页模式

```python
# URL 模板 + 循环
for page_num in range(1, 6):
    url = f"https://example.com/page/{page_num}/"
    page = f.get(url)
    # 提取...
    time.sleep(1)
```